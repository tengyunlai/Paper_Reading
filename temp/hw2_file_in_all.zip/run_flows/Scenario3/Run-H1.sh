#!/bin/bash
iperf3 -c 10.0.0.4 -b 30M -t 300 -u